# Homework 3: Use of Semaphores

## Objectives
In this homework, you learn how

- to use semaphores to synchronise threads in a concurrent program with shared variables.
- to use semaphores to control access to shared resources.

